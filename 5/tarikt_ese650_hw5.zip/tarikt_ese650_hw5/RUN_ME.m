load road_model
%load pedestrian_model
load smallmap
%%
interactive_planner( map, cost_map );