function [ quantized ] = quantizeData(  )


end