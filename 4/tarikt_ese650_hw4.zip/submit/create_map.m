function map = create_map( params )
%
% Creates and returns the map based on params.
map = zeros(params.sizex,params.sizey,'int8');

end