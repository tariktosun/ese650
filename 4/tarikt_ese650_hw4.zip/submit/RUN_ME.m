T = test_slam();
T.setup();
T.test_test_set();